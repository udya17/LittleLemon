import Header from '../Components/Header';
import Nav from '../Components/Nav';

function ConfirmationPage() {
    return(
        <>
        <Header></Header>
        <Nav></Nav>
        <h1>Success! Your booking has been confirmed.</h1>
        </>
    );
}

export default ConfirmationPage;