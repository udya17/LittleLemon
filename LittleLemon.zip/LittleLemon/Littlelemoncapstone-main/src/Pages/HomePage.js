import Header from '../Components/Header';
import Nav from '../Components/Nav';

function HomePage() {
    return(
        <>
        <Header></Header>
        <Nav></Nav>
        </>
    );
}

export default HomePage;